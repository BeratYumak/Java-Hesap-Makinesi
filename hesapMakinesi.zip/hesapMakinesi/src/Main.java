public class Main {
	public static void main(String[] args) {
		//girdiler
		İnput i̇nput = new İnput();
		i̇nput.input();
		}
	}
