import java.util.InputMismatchException;
import java.util.Scanner;
public class İnput implements IToplama, ICikarma, ICarpma, IBölme {
	public void input() {

		boolean a = true;
		while (a) {
			try {

				//işlem sorgusu
				Scanner scanner = new Scanner(System.in);
				System.out.println("Toplama için: 1");
				System.out.println("Çıkarma için: 2");
				System.out.println("Bölme için: 3");
				System.out.println("Çarpma için: 4");
				System.out.println("Çıkmak için: 5'e basınız.");

				//işlem türü
				int process = scanner.nextInt();

				//işlem sonlandırma.
				if (process == 5) {
					a = false;
					System.out.println("Kapatılıyor");
					break;
				}

				//birinci sayı girdisi.
				System.out.println("Birinci sayıyı giriniz: ");
				int number1 = scanner.nextInt();
				//ikinci sayı girdisi.
				System.out.println("İkinci sayıyı giriniz: ");
				int number2 = scanner.nextInt();

				//toplama
				if (process == 1) {
					IToplama.topla(number1, number2);
				}
				//çıkarma
				if (process == 2) {
					ICikarma.cikar(number1, number2);
				}
				//bölme
				if (process == 3) {
					IBölme.böl(number1, number2);
				}
				//çarpma
				if (process == 4) {
					ICarpma.carp(number1, number2);
				}
				//sayı dışı girişi
			} catch (InputMismatchException inputMismatchException) {
				System.out.println("Lütfen sayı giriniz");
				System.out.println("");
			}
		}
	}
}