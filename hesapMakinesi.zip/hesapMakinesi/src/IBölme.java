public interface IBölme {
	 static void böl(double number1, double number2) {
		 double sonuc = number1 / number2;
		 if (number2 == 0) {
			 System.out.println("Sıfıra bölünemez");
			 System.out.println("");
		 } else {
		 System.out.println("Sonuc: " + sonuc);
		 System.out.println("");
		 }
	}
}
