public interface ICarpma {
	static void carp(double number1, double number2){
		double sonuc = number1 * number2;
		System.out.println("Sonuc: "+sonuc);
		System.out.println("");
	}
}
